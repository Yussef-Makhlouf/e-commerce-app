import React from "react";
import './cart.css'
export default function NotFoundPage(){
    const s={
      
    }
    return (
        <div className="NotFoundPage ">
            <div>
                <h1>Page Not Found</h1>
                <p>Sorry, the page you are looking for does not exist.</p>
                <a href="/" className="btn btn-primary">Go Home</a>

            </div>
           
            
        </div>
    );
}