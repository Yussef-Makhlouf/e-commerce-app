
// import React, { useEffect, useMemo, useState } from "react";
// import axios from "axios";
// import { useSelector, useDispatch } from "react-redux";
// import { fetchProducts } from "../redux/slices/productSlice.js";
// import { toggleFavorite } from "../redux/slices/favoriteSlice.js";
// import { setPage } from "../redux/slices/paginationSlice.js";
// import toast, { Toaster } from 'react-hot-toast';
//  import { InputGroup,
//   FormControl,
//   Card,
//   ListGroup,
//   Badge,
//   Spinner,
//   Container,
//   Row,
//   Col,
//   Pagination,
//   Button,
//   Modal
// ,Form,
// } from "react-bootstrap";
// export default function AdminPanel() {
//   const [products,setProducts]=useState([])
//   const [showUpdateModal, setShowUpdateModal] = useState(false);
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const [file, setFile] = useState(null);
//   // const [page,setPage]=useState(1)
//   // const handleChangePage=(pageNumber)=>
//   //   {
//   //       setPage(pageNumber)

//   //   }
//    useEffect(()=>{
//     (async()=>{
//       try {
//         const response = await axios.get("http://localhost:5000/api/v1/react/products");
//         if (response.data && response.data[1]?.products) {
//           setProducts(response.data[1]?.products); // return response.data[1]?.products
 
//         } else {
//           setProducts([]); 
       
//         }
//       } catch (error) {
//         console.error("Error fetching products:", error);
//         setProducts([]); 

//       }
//     })()
// },[])

// const handleCloseUpdateModal = () => setShowUpdateModal(false);

// const handleUpdateSubmit = async (e) => {
//   e.preventDefault();

//   const formData = new FormData();
//   formData.append("productName", selectedProduct.productName);
//   formData.append("price", selectedProduct.price);
//   formData.append("description", selectedProduct.description);
//   formData.append("category", selectedProduct.category);

//   if (file) {
//     formData.append("photo", file);
//   }

//   try { 
//     await axios.patch(`http://localhost:5000/api/v1/react/products/${selectedProduct.id}`, formData, {
      
//       headers: {
//         "Content-Type": "multipart/form-data",
//       },
//     });

//     // Optionally, fetch products again or update state
//     setShowUpdateModal(false);
//   } catch (error) {
//     console.error("Error updating product:", error);
//   }
// };
// const handleUpdate = (id) => {
  
//   const product = products.find((product) => product.id === id);
  
//     setSelectedProduct(product);
//     console.log(product);
//   setShowUpdateModal(true);
// };

// const handleDelete = async (id) => {
//   try {
//     toast((t) => (
//       <span>
//         are you sure you want to delete this product?
//         <button onClick={() => toast.dismiss(t.id)}>
//           ok
//         </button>
//       </span>
//     ));
//     const response = await axios.delete(`http://localhost:5000/api/v1/react/products/${id}`);
//     if (response.data.msg === "success") {
//       setProducts((prevProducts) => prevProducts.filter((product) => product.id !== id));
//     }
//   } catch (error) {
//     console.error("Error deleting product:", error);
//   }
// };

//   return(<>
           
//           <Row>
// {Array.isArray(products) && products.length > 0 ? (
//           products.map((product, index) => (
          
//               <Col key={`${product.id}-${index}`} md={6} lg={4} className="mb-3">
//                 <Card >
//                   <Card.Img
//                     variant="top"
//                     src={product.photo}
//                     alt={product.productName}
//                     style={{ cursor: "pointer",width:"100%",height:"200px",objectFit:"contain"}}
                 
//                   />
//                   <Card.Body>
//                     <Card.Title>{product.productName}</Card.Title>
//                     <Card.Text>{product.description}</Card.Text>
//                     <ListGroup variant="flush" className="mb-2">
//                       <ListGroup.Item>
//                         Price:{" "}
//                         <Badge bg="success" className="ms-2">
//                           {product.price}$
//                         </Badge>
//                       </ListGroup.Item>
//                       <ListGroup.Item>
//                         Rating: {product.ratingsAvg}
//                         {/* {renderStars(product.ratingsAvg)} */}
//                       </ListGroup.Item>
                   
//                     </ListGroup>
//                    <Button onClick={()=>handleUpdate(product.id)}>update</Button><Button  onClick={() => handleDelete(product.id)}>Delete</Button>
//                   </Card.Body>
//                 </Card>
//               </Col>
//             ))
//           ) : (
//             <p></p>
//           )}
//             </Row>
//             <Modal show={showUpdateModal} onHide={handleCloseUpdateModal}>
//       <Modal.Header closeButton>
//         <Modal.Title>Update Product</Modal.Title>
//       </Modal.Header>
//       <Modal.Body>
//         <Form onSubmit={handleUpdateSubmit}>
//           <Form.Group controlId="productName">
//             <Form.Label>Product Name</Form.Label>
//             <Form.Control
//               type="text"
//               name="productName"
//               value={selectedProduct?.productName || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   productName: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="price">
//             <Form.Label>Price</Form.Label>
//             <Form.Control
//               type="number"
//               name="price"
//               value={selectedProduct?.price || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   price: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="description">
//             <Form.Label>Description</Form.Label>
//             <Form.Control
//               as="textarea"
//               name="description"
//               value={selectedProduct?.description || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   description: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="category">
//             <Form.Label>Category</Form.Label>
//             <Form.Control
//               type="text"
//               name="category"
//               value={selectedProduct?.category || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   category: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="photo">
//             <Form.Label>Photo</Form.Label>
//             <Form.Control
//               type="file"
//               name="photo"
              
//               onChange={(e) => setFile(e.target.files[0])}
//             />
//           </Form.Group>

//           <Button variant="primary" type="submit">
//             Update Product
//           </Button>
//         </Form>
//       </Modal.Body>
//     </Modal>
//     {/* <nav>
//         <ul className="pagination justify-content-center">
//           {[1, 2, 3, 4, 5,6,7,8,9,10].map((pageNumber) => (
//             <li
//               className={`page-item ${pageNumber === page ? "active" : ""}`}
//               key={pageNumber}
//               onClick={() => handleChangePage(pageNumber)}
//             >
//               <span className="page-link">{pageNumber}</span>
//             </li>
//           ))}
//         </ul>
//         </nav> */}
//   </>)
// }
// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import toast, { Toaster } from 'react-hot-toast';
// import {
//   InputGroup,
//   FormControl,
//   Card,
//   ListGroup,
//   Badge,
//   Row,
//   Col,
//   Button,
//   Modal,
//   Form,
// } from "react-bootstrap";

// export default function AdminPanel() {
//   const [products, setProducts] = useState([]);
//   const [showUpdateModal, setShowUpdateModal] = useState(false);
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const [file, setFile] = useState(null);

//   useEffect(() => {
//     (async () => {
//       try {
//         const response = await axios.get("http://localhost:5000/api/v1/react/products");
//         if (response.data && response.data[1]?.products) {
//           setProducts(response.data[1]?.products);
//         } else {
//           setProducts([]);
//         }
//       } catch (error) {
//         console.error("Error fetching products:", error);
//         toast.error("Failed to fetch products");
//         setProducts([]);
//       }
//     })();
//   }, []);

//   const handleCloseUpdateModal = () => {
//     setShowUpdateModal(false);
//     setSelectedProduct(null);
//     setFile(null);
//   };

//   const handleUpdateSubmit = async (e) => {
//     e.preventDefault();

//     const formData = new FormData();
//     formData.append("productName", selectedProduct.productName);
//     formData.append("price", selectedProduct.price);
//     formData.append("description", selectedProduct.description);
//     formData.append("category", selectedProduct.category);

//     if (file) {
//       formData.append("photo", file);
//     }

//     try {
//       await axios.patch(
//         `http://localhost:5000/api/v1/react/products/${selectedProduct.id}`,
//         formData,
//         {
//           headers: {
//             "Content-Type": "multipart/form-data",
//           },
//         }
//       );

//       setProducts((prevProducts) =>
//         prevProducts.map((product) =>
//           product.id === selectedProduct.id ? { ...product, ...selectedProduct, photo: file ? URL.createObjectURL(file) : product.photo } : product
//         )
//       );

//       toast.success("Product updated successfully!");
//       handleCloseUpdateModal();
//     } catch (error) {
//       console.error("Error updating product:", error);
//       toast.error("Failed to update product");
//     }
//   };

//   const handleUpdate = (id) => {
//     const product = products.find((product) => product.id === id);
//     setSelectedProduct(product);
//     setShowUpdateModal(true);
//   };

//   const handleDelete = async (id) => {
//     toast(
//       (t) => (
//         <span>
//           Are you sure you want to delete this product?
//           <Button
//             onClick={async () => {
//               toast.dismiss(t.id);
//               try {
//                 const response = await axios.delete(`http://localhost:5000/api/v1/react/products/${id}`);
//                 if (response.data.msg === "success") {
//                   setProducts((prevProducts) => prevProducts.filter((product) => product.id !== id));
//                   toast.success("Product deleted successfully!");
//                 }
//               } catch (error) {
//                 console.error("Error deleting product:", error);
//                 toast.error("Failed to delete product");
//               }
//             }}
//           >
//             OK
//           </Button>
//         </span>
//       ),
//       { duration: 4000 }
//     );
//   };

//   return (
//     <>
//       <Toaster />
//       <Row>
//         {Array.isArray(products) && products.length > 0 ? (
//           products.map((product, index) => (
//             <Col key={`${product.id}-${index}`} md={6} lg={4} className="mb-3">
//               <Card>
//                 <Card.Img
//                   variant="top"
//                   src={product.photo}
//                   alt={product.productName}
//                   style={{ cursor: "pointer", width: "100%", height: "200px", objectFit: "contain" }}
//                 />
//                 <Card.Body>
//                   <Card.Title>{product.productName}</Card.Title>
//                   <Card.Text>{product.description}</Card.Text>
//                   <ListGroup variant="flush" className="mb-2">
//                     <ListGroup.Item>
//                       Price:{" "}
//                       <Badge bg="success" className="ms-2">
//                         {product.price}$
//                       </Badge>
//                     </ListGroup.Item>
//                     <ListGroup.Item>Rating: {product.ratingsAvg}</ListGroup.Item>
//                   </ListGroup>
//                   <Button variant="primary" onClick={() => handleUpdate(product.id)}>Update</Button>
//                   <Button variant="danger" onClick={() => handleDelete(product.id)} className="ms-2">Delete</Button>
//                 </Card.Body>
//               </Card>
//             </Col>
//           ))
//         ) : (
//           <p>No products found.</p>
//         )}
//       </Row>

//       {selectedProduct && (
//         <UpdateProductModal
//           show={showUpdateModal}
//           handleClose={handleCloseUpdateModal}
//           selectedProduct={selectedProduct}
//           setSelectedProduct={setSelectedProduct}
//           handleUpdateSubmit={handleUpdateSubmit}
//           setFile={setFile}
//         />
//       )}
//     </>
//   );
// }

// function UpdateProductModal({
//   show,
//   handleClose,
//   selectedProduct,
//   setSelectedProduct,
//   handleUpdateSubmit,
//   setFile,
// }) {
//   return (
//     <Modal show={show} onHide={handleClose}>
//       <Modal.Header closeButton>
//         <Modal.Title>Update Product</Modal.Title>
//       </Modal.Header>
//       <Modal.Body>
//         <Form onSubmit={handleUpdateSubmit}>
//           <Form.Group controlId="productName">
//             <Form.Label>Product Name</Form.Label>
//             <Form.Control
//               type="text"
//               name="productName"
//               value={selectedProduct?.productName || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   productName: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="price">
//             <Form.Label>Price</Form.Label>
//             <Form.Control
//               type="number"
//               name="price"
//               value={selectedProduct?.price || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   price: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="description">
//             <Form.Label>Description</Form.Label>
//             <Form.Control
//               as="textarea"
//               name="description"
//               value={selectedProduct?.description || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   description: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="category">
//             <Form.Label>Category</Form.Label>
//             <Form.Control
//               type="text"
//               name="category"
//               value={selectedProduct?.category || ""}
//               onChange={(e) =>
//                 setSelectedProduct({
//                   ...selectedProduct,
//                   category: e.target.value,
//                 })
//               }
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="photo">
//             <Form.Label>Photo</Form.Label>
//             <Form.Control
//               type="file"
//               name="photo"
//               onChange={(e) => setFile(e.target.files[0])}
//             />
//           </Form.Group>

//           <Button variant="primary" type="submit">
//             Update Product
//           </Button>
//         </Form>
//       </Modal.Body>
//     </Modal>
//   );
// }
// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import {
//   Button,
//   Card,
//   ListGroup,
//   Badge,
//   Modal,
//   Form,
//   Row,
//   Col,
//   Pagination,
// } from "react-bootstrap";
// import toast, { Toaster } from "react-hot-toast";
// import { FaStar, FaEdit, FaTrashAlt } from "react-icons/fa";

// export default function AdminPanel() {
//   const [products, setProducts] = useState([]);
//   const [showUpdateModal, setShowUpdateModal] = useState(false);
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const [file, setFile] = useState(null);
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 6; // Number of items per page

//   useEffect(() => {
//     (async () => {
//       try {
//         const response = await axios.get(
//           `http://localhost:5000/api/v1/react/products?page=${currentPage}&limit=${itemsPerPage}`
//         );
//         if (response.data && response.data[1]?.products) {
//           setProducts(response.data[1]?.products);
//         } else {
//           setProducts([]);
//         }
//       } catch (error) {
//         console.error("Error fetching products:", error);
//         setProducts([]);
//       }
//     })();
//   }, [currentPage]);

//   const handleCloseUpdateModal = () => setShowUpdateModal(false);

//   const handleUpdateSubmit = async (e) => {
//     e.preventDefault();
//     const formData = new FormData();
//     formData.append("productName", selectedProduct.productName);
//     formData.append("price", selectedProduct.price);
//     formData.append("description", selectedProduct.description);
//     formData.append("category", selectedProduct.category);
//     if (file) formData.append("photo", file);

//     try {
//       await axios.patch(
//         `http://localhost:5000/api/v1/react/products/${selectedProduct.id}`,
//         formData,
//         {
//           headers: { "Content-Type": "multipart/form-data" },
//         }
//       );
//       setShowUpdateModal(false);
//     } catch (error) {
//       console.error("Error updating product:", error);
//     }
//   };

//   const handleUpdate = (id) => {
//     const product = products.find((product) => product.id === id);
//     setSelectedProduct(product);
//     setShowUpdateModal(true);
//   };

//   const handleDelete = async (id) => {
//     try {
//       toast((t) => (
//         <span>
//           Are you sure you want to delete this product?
//           <button onClick={() => toast.dismiss(t.id)}>OK</button>
//         </span>
//       ));
//       const response = await axios.delete(
//         `http://localhost:5000/api/v1/react/products/${id}`
//       );
//       if (response.data.msg === "success") {
//         setProducts((prevProducts) =>
//           prevProducts.filter((product) => product.id !== id)
//         );
//       }
//     } catch (error) {
//       console.error("Error deleting product:", error);
//     }
//   };

//   const totalPages = Math.ceil(20 / itemsPerPage); // Assuming you have 20 products for example

//   const handlePageChange = (pageNumber) => {
//     setCurrentPage(pageNumber);
//   };

//   return (
//     <>
//       <Row>
//         {Array.isArray(products) && products.length > 0 ? (
//           products.map((product, index) => (
//             <Col key={`${product.id}-${index}`} md={6} lg={4} className="mb-3">
//               <Card className="shadow-sm">
//                 <Card.Img
//                   variant="top"
//                   src={product.photo}
//                   alt={product.productName}
//                   style={{
//                     cursor: "pointer",
//                     width: "100%",
//                     height: "200px",
//                     objectFit: "contain",
//                   }}
//                 />
//                 <Card.Body>
//                   <Card.Title>{product.productName}</Card.Title>
//                   <Card.Text>{product.description}</Card.Text>
//                   <ListGroup variant="flush" className="mb-2">
//                     <ListGroup.Item>
//                       Price:{" "}
//                       <Badge
//                         bg="info"
//                         className="ms-2"
//                         style={{ fontSize: "1rem" }}
//                       >
//                         {product.price}$
//                       </Badge>
//                     </ListGroup.Item>
//                     <ListGroup.Item>
//                       Rating:{" "}
//                       <span>
//                         {[...Array(Math.round(product.ratingsAvg))].map(
//                           (_, i) => (
//                             <FaStar key={i} color="gold" />
//                           )
//                         )}
//                       </span>
//                     </ListGroup.Item>
//                   </ListGroup>
//                   <div className="d-flex justify-content-between">
//                     <Button
//                       variant="outline-primary"
//                       className="me-2"
//                       onClick={() => handleUpdate(product.id)}
//                     >
//                       <FaEdit /> Update
//                     </Button>
//                     <Button
//                       variant="outline-danger"
//                       onClick={() => handleDelete(product.id)}
//                     >
//                       <FaTrashAlt /> Delete
//                     </Button>
//                   </div>
//                 </Card.Body>
//               </Card>
//             </Col>
//           ))
//         ) : (
//           <p>No products found.</p>
//         )}
//       </Row>

//       <Pagination className="justify-content-center mt-4">
//         <Pagination.First
//           onClick={() => handlePageChange(1)}
//           disabled={currentPage === 1}
//         />
//         <Pagination.Prev
//           onClick={() => handlePageChange(currentPage - 1)}
//           disabled={currentPage === 1}
//         />
//         {[...Array(totalPages)].map((_, index) => (
//           <Pagination.Item
//             key={index + 1}
//             active={index + 1 === currentPage}
//             onClick={() => handlePageChange(index + 1)}
//           >
//             {index + 1}
//           </Pagination.Item>
//         ))}
//         <Pagination.Next
//           onClick={() => handlePageChange(currentPage + 1)}
//           disabled={currentPage === totalPages}
//         />
//         <Pagination.Last
//           onClick={() => handlePageChange(totalPages)}
//           disabled={currentPage === totalPages}
//         />
//       </Pagination>

//       <Modal show={showUpdateModal} onHide={handleCloseUpdateModal}>
//         <Modal.Header closeButton>
//           <Modal.Title>Update Product</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <Form onSubmit={handleUpdateSubmit}>
//             <Form.Group controlId="productName">
//               <Form.Label>Product Name</Form.Label>
//               <Form.Control
//                 type="text"
//                 name="productName"
//                 value={selectedProduct?.productName || ""}
//                 onChange={(e) =>
//                   setSelectedProduct({
//                     ...selectedProduct,
//                     productName: e.target.value,
//                   })
//                 }
//                 required
//               />
//             </Form.Group>
//             <Form.Group controlId="price">
//               <Form.Label>Price</Form.Label>
//               <Form.Control
//                 type="number"
//                 name="price"
//                 value={selectedProduct?.price || ""}
//                 onChange={(e) =>
//                   setSelectedProduct({
//                     ...selectedProduct,
//                     price: e.target.value,
//                   })
//                 }
//                 required
//               />
//             </Form.Group>
//             <Form.Group controlId="description">
//               <Form.Label>Description</Form.Label>
//               <Form.Control
//                 as="textarea"
//                 name="description"
//                 value={selectedProduct?.description || ""}
//                 onChange={(e) =>
//                   setSelectedProduct({
//                     ...selectedProduct,
//                     description: e.target.value,
//                   })
//                 }
//                 required
//               />
//             </Form.Group>
//             <Form.Group controlId="category">
//               <Form.Label>Category</Form.Label>
//               <Form.Control
//                 type="text"
//                 name="category"
//                 value={selectedProduct?.category || ""}
//                 onChange={(e) =>
//                   setSelectedProduct({
//                     ...selectedProduct,
//                     category: e.target.value,
//                   })
//                 }
//                 required
//               />
//             </Form.Group>
//             <Form.Group controlId="photo">
//               <Form.Label>Photo</Form.Label>
//               <Form.Control
//                 type="file"
//                 name="photo"
//                 onChange={(e) => setFile(e.target.files[0])}
//               />
//             </Form.Group>
//             <Button variant="primary" type="submit">
//               Update Product
//             </Button>
//           </Form>
//         </Modal.Body>
//       </Modal>
//     </>
//   );
// }
import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Button,
  Card,
  ListGroup,
  Badge,
  Modal,
  Form,
  Row,
  Col,
  Pagination,
} from "react-bootstrap";
import toast, { Toaster } from "react-hot-toast";
import { FaStar, FaEdit, FaTrashAlt } from "react-icons/fa";

export default function AdminPanel() {
  const [products, setProducts] = useState([]);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [file, setFile] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10; // Number of items per page

  useEffect(() => {
    (async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/api/v1/react/products?page=${currentPage}&limit=${itemsPerPage}`
        );
        if (response.data && response.data[1]?.products) {
          setProducts(response.data[1]?.products);
        } else {
          setProducts([]);
        }
      } catch (error) {
        console.error("Error fetching products:", error);
        setProducts([]);
      }
    })();
  }, [currentPage]);

  const handleCloseUpdateModal = () => setShowUpdateModal(false);

  const handleUpdateSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("productName", selectedProduct.productName);
    formData.append("price", selectedProduct.price);
    formData.append("description", selectedProduct.description);
    formData.append("category", selectedProduct.category);
    if (file) formData.append("photo", file);

    try {
      await axios.patch(
        `http://localhost:5000/api/v1/react/products/${selectedProduct.id}`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      setShowUpdateModal(false);
      toast.success("Product updated successfully!");
    } catch (error) {
      console.error("Error updating product:", error);
      toast.error("Failed to update the product.");
    }
  };

  const handleUpdate = (id) => {
    const product = products.find((product) => product.id === id);
    setSelectedProduct(product);
    setShowUpdateModal(true);
  };

  const handleDelete = async (id) => {
    try {
      toast(
        (t) => (
          <span>
            Are you sure you want to delete this product?
            <Button
              variant="outline-danger"
              size="sm"
              onClick={async () => {
                await axios.delete(
                  `http://localhost:5000/api/v1/react/products/${id}`
                );
                setProducts((prevProducts) =>
                  prevProducts.filter((product) => product.id !== id)
                );
                toast.dismiss(t.id);
                toast.success("Product deleted successfully!");
              }}
              className="ms-2"
            >
              Yes
            </Button>
            <Button
              variant="outline-secondary"
              size="sm"
              onClick={() => toast.dismiss(t.id)}
              className="ms-2"
            >
              No
            </Button>
          </span>
        ),
        { duration: 5000 }
      );
    } catch (error) {
      console.error("Error deleting product:", error);
      toast.error("Failed to delete the product.");
    }
  };

  const totalPages = Math.ceil(20 / itemsPerPage); // Assuming you have 20 products for example

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <>
      <Toaster position="top-center" reverseOrder={false} />

      <Row>
        {Array.isArray(products) && products.length > 0 ? (
          products.map((product, index) => (
            <Col key={`${product.id}-${index}`} md={6} lg={4} className="mb-3">
              <Card className="shadow-sm" style={{ borderRadius: "10px" }}>
                <Card.Img
                  variant="top"
                  src={product.photo}
                  alt={product.productName}
                  style={{
                    cursor: "pointer",
                    width: "100%",
                    height: "200px",
                    objectFit: "contain",
                    borderTopLeftRadius: "10px",
                    borderTopRightRadius: "10px",
                  }}
                />
                <Card.Body>
                  <Card.Title className="text-center" style={{ fontWeight: "bold" }}>
                    {product.productName}
                  </Card.Title>
                  <Card.Text className="text-muted">
                    {product.description}
                  </Card.Text>
                  <ListGroup variant="flush" className="mb-2">
                    <ListGroup.Item>
                      Price:{" "}
                      <Badge
                        bg="info"
                        className="ms-2"
                        style={{ fontSize: "1rem" }}
                      >
                        {product.price}$
                      </Badge>
                    </ListGroup.Item>
                    <ListGroup.Item>
                      Rating:{" "}
                      <span>
                        {[...Array(Math.round(product.ratingsAvg))].map(
                          (_, i) => (
                            <FaStar key={i} color="gold" />
                          )
                        )}
                      </span>
                    </ListGroup.Item>
                  </ListGroup>
                  <div className="d-flex justify-content-between">
                    <Button
                      variant="outline-primary"
                      className="me-2"
                      onClick={() => handleUpdate(product.id)}
                      style={{
                        fontWeight: "bold",
                        borderRadius: "5px",
                      }}
                    >
                      <FaEdit /> Update
                    </Button>
                    <Button
                      variant="outline-danger"
                      onClick={() => handleDelete(product.id)}
                      style={{
                        fontWeight: "bold",
                        borderRadius: "5px",
                      }}
                    >
                      <FaTrashAlt /> Delete
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))
        ) : (
          <p>No products found.</p>
        )}
      </Row>

      <Pagination className="justify-content-center mt-4">
        <Pagination.First
          onClick={() => handlePageChange(1)}
          disabled={currentPage === 1}
        />
        <Pagination.Prev
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        />
        {[...Array(totalPages)].map((_, index) => (
          <Pagination.Item
            key={index + 1}
            active={index + 1 === currentPage}
            onClick={() => handlePageChange(index + 1)}
          >
            {index + 1}
          </Pagination.Item>
        ))}
        <Pagination.Next
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
        />
        <Pagination.Last
          onClick={() => handlePageChange(totalPages)}
          disabled={currentPage === totalPages}
        />
      </Pagination>

      <Modal show={showUpdateModal} onHide={handleCloseUpdateModal}>
        <Modal.Header closeButton>
          <Modal.Title>Update Product</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleUpdateSubmit}>
            <Form.Group controlId="productName">
              <Form.Label>Product Name</Form.Label>
              <Form.Control
                type="text"
                name="productName"
                value={selectedProduct?.productName || ""}
                onChange={(e) =>
                  setSelectedProduct({
                    ...selectedProduct,
                    productName: e.target.value,
                  })
                }
                required
              />
            </Form.Group>
            <Form.Group controlId="price">
              <Form.Label>Price</Form.Label>
              <Form.Control
                type="number"
                name="price"
                value={selectedProduct?.price || ""}
                onChange={(e) =>
                  setSelectedProduct({
                    ...selectedProduct,
                    price: e.target.value,
                  })
                }
                required
              />
            </Form.Group>
            <Form.Group controlId="description">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                name="description"
                value={selectedProduct?.description || ""}
                onChange={(e) =>
                  setSelectedProduct({
                    ...selectedProduct,
                    description: e.target.value,
                  })
                }
                required
              />
            </Form.Group>
            <Form.Group controlId="category">
              <Form.Label>Category</Form.Label>
              <Form.Control
                type="text"
                name="category"
                value={selectedProduct?.category || ""}
                onChange={(e) =>
                  setSelectedProduct({
                    ...selectedProduct,
                    category: e.target.value,
                  })
                }
                required
              />
            </Form.Group>
            <Form.Group controlId="photo">
              <Form.Label>Photo</Form.Label>
              <Form.Control
                type="file"
                name="photo"
                onChange={(e) => setFile(e.target.files[0])}
              />
            </Form.Group>
            <Button
              variant="primary"
              type="submit"
              style={{ fontWeight: "bold" }}
            >
                            Update
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  );
}

