

import { useState } from 'react';
import { Button, Card, Modal, Form, InputGroup } from 'react-bootstrap';

export default function ProductAdmin() {
  const [products, setProducts] = useState([
    {
      id: 1,
      name: "Cozy Blanket",
      description: "Warm and Soft for Chilly Nights",
      price: 29.99,
      inventory: 50,
      images: ["/placeholder.svg"],
      category: "Home",
    },
    {
      id: 2,
      name: "Autumn Mug",
      description: "Enjoy Your Hot Beverages in Style",
      price: 12.99,
      inventory: 75,
      images: ["/placeholder.svg"],
      category: "Kitchen",
    },
    {
      id: 3,
      name: "Fall Fragrance Candle",
      description: "Fill Your Space with a Cozy Scent",
      price: 16.99,
      inventory: 30,
      images: ["/placeholder.svg"],
      category: "Home",
    },
    {
      id: 4,
      name: "Autumn Leaves Wall Art",
      description: "Decorate Your Space with Nature's Beauty",
      price: 39.99,
      inventory: 20,
      images: ["/placeholder.svg"],
      category: "Decor",
    },
  ]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showProductModal, setShowProductModal] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const [imageFile, setImageFile] = useState(null);

  const handleAddProduct = () => {
    setSelectedProduct(null);
    setShowProductModal(true);
    setImagePreview(null);
    setImageFile(null);
  };

  const handleEditProduct = (product) => {
    setSelectedProduct(product);
    setShowProductModal(true);
    setImagePreview(product.images[0]);
    setImageFile(null);
  };

  const handleDeleteProduct = (id) => {
    setProducts(products.filter((product) => product.id !== id));
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    setImageFile(file);

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const handleSaveProduct = () => {
    const form = document.getElementById('productForm');
    const formData = new FormData(form);

    const product = {
      id: selectedProduct ? selectedProduct.id : Date.now(),
      name: formData.get('name'),
      description: formData.get('description'),
      price: parseFloat(formData.get('price')),
      inventory: parseInt(formData.get('inventory')),
      category: formData.get('category'),
      images: imagePreview ? [imagePreview] : selectedProduct?.images || [],
    };

    if (selectedProduct) {
      setProducts(products.map((p) => (p.id === product.id ? product : p)));
    } else {
      setProducts([...products, product]);
    }
    setShowProductModal(false);
  };

  return (
    <div className="container-fluid">
      <header className="d-flex justify-content-between align-items-center py-3 border-bottom bg-light">
        <h1 className="h4">Products</h1>
        <Button onClick={handleAddProduct}>Add Product</Button>
      </header>
      <main className="py-4">
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
          {products.map((product) => (
            <div className="col" key={product.id}>
              <Card>
                <Card.Img variant="top" src={product.images[0]} alt={product.name} />
                <Card.Body>
                  <Card.Title>{product.name}</Card.Title>
                  <Card.Text>{product.description}</Card.Text>
                  <div className="d-flex justify-content-between">
                    <span>Category: {product.category}</span>
                    <span>${product.price.toFixed(2)}</span>
                    <span>{product.inventory} in stock</span>
                  </div>
                </Card.Body>
                <Card.Footer className="d-flex justify-content-end">
                  <Button variant="outline-primary" onClick={() => handleEditProduct(product)}>
                    Edit
                  </Button>
                  <Button variant="outline-danger" className="ms-2" onClick={() => handleDeleteProduct(product.id)}>
                    Delete
                  </Button>
                </Card.Footer>
              </Card>
            </div>
          ))}
        </div>
      </main>

      <Modal show={showProductModal} onHide={() => setShowProductModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>{selectedProduct ? 'Edit Product' : 'Add Product'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form id="productForm">
            <Form.Group controlId="name" className="mb-3">
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" name="name" defaultValue={selectedProduct?.name || ''} placeholder="Product Name" />
            </Form.Group>
            <Form.Group controlId="description" className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control as="textarea" name="description" defaultValue={selectedProduct?.description || ''} placeholder="Product Description" rows={3} />
            </Form.Group>
            <Form.Group controlId="price" className="mb-3">
              <Form.Label>Price</Form.Label>
              <Form.Control type="number" name="price" defaultValue={selectedProduct?.price || ''} placeholder="Price" />
            </Form.Group>
            <Form.Group controlId="inventory" className="mb-3">
              <Form.Label>Inventory</Form.Label>
              <Form.Control type="number" name="inventory" defaultValue={selectedProduct?.inventory || ''} placeholder="Inventory" />
            </Form.Group>
            <Form.Group controlId="category" className="mb-3">
              <Form.Label>Category</Form.Label>
              <Form.Select name="category" defaultValue={selectedProduct?.category || ''}>
                <option value="">Select category</option>
                <option value="Home">Home</option>
                <option value="Kitchen">Kitchen</option>
                <option value="Decor">Decor</option>
                <option value="Clothing">Clothing</option>
                <option value="Electronics">Electronics</option>
              </Form.Select>
            </Form.Group>
            <Form.Group controlId="images" className="mb-3">
              <Form.Label>Images</Form.Label>
              <InputGroup>
                <Form.Control type="file" onChange={handleImageChange} />
              </InputGroup>
              {imagePreview && <img src={imagePreview} alt="Preview" className="img-thumbnail mt-2" />}
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowProductModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSaveProduct}>
            Save
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
